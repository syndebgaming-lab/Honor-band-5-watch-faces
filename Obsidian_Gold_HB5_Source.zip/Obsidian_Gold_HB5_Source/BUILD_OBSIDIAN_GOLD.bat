@echo off
cd /d "%~dp0"
call package_bandtool.bat
