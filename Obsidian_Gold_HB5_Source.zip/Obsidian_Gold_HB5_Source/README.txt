OBSIDIAN GOLD — HONOR BAND 5 SOURCE PROJECT

Device target: HONOR Band 5 / HWHD03 / 120 x 240
Firmware reported by user: 1.1.0.162

CONTENTS
- watchface/: modified source project, XML configuration and bitmap assets
- bandtools/: original packaging tools supplied in the user's source archive
- package_bandtool.bat: original Windows packaging workflow
- preview_120x240.png: static preview with illustrative sample values

BUILD
1. Extract this folder on a Windows PC.
2. Keep the directory layout unchanged.
3. Run package_bandtool.bat from this folder (double-click or run from cmd).
4. The script should create the compiled watch-face package using TemplateWatch.exe.
5. Check the resulting .hwt and confirm it is below the Band 5 package limits before installing.

IMPORTANT
This environment cannot execute the included Windows .exe packaging tools, so no compiled
com.huawei.watchface or installable .hwt is included. The XML widget names and resource
mapping in this source project are based on publicly available Huawei Band 5 documentation,
but they have not been validated by running the original compiler or installing on a band.
Treat this as a build-ready source attempt, not a tested installation package. Test first
with a non-critical watch face and retain your existing face in case the band rejects it.

The preview contains example values (10:08, 01 NOV, 72 BPM, 85%, 6,842 steps). The actual
watch-face widgets are configured to request live values from the band.
